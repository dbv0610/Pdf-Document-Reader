/*
 * 文件名称:          LaterStarPathBuilder.java
 *  
 * 编译器:            android2.2
 * 时间:              下午3:38:25
 */
package com.wxiwei.office.common.autoshape.pathbuilder.starAndBanner.star

import android.graphics.Matrix
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import com.wxiwei.office.common.shape.AutoShape
import com.wxiwei.office.common.shape.ShapeTypes
import kotlin.math.min

/**
 * TODO: 文件注释
 * 
 * 
 * 
 * 
 * Read版本:        Read V1.0
 * 
 * 
 * 作者:            jqin
 * 
 * 
 * 日期:            2012-10-19
 * 
 * 
 * 负责人:           jqin
 * 
 * 
 * 负责小组:
 * 
 * 
 * 
 * 
 */
object LaterStarPathBuilder {
    private val sm = Matrix()
    var s_rect: RectF = RectF()


    @JvmStatic
    fun getStarPath(shape: AutoShape, rect: Rect): Path? {
        when (shape.shapeType) {
            ShapeTypes.Star4 -> return getStar4Path(shape, rect)

            ShapeTypes.Star5, ShapeTypes.Star -> return getStar5Path(shape, rect)

            ShapeTypes.Star6 -> return getStar6Path(shape, rect)

            ShapeTypes.Star7 -> return getStar7Path(shape, rect)

            ShapeTypes.Star8 -> return getStar8Path(shape, rect)

            ShapeTypes.Star10 -> return getStar10Path(shape, rect)

            ShapeTypes.Star12 -> return getStar12Path(shape, rect)

            ShapeTypes.Star16 -> return getStar16Path(shape, rect)

            ShapeTypes.Star24 -> return getStar24Path(shape, rect)

            ShapeTypes.Star32 -> return getStar32Path(shape, rect)
        }

        return null
    }

    private fun getStar4Path(shape: AutoShape, rect: Rect): Path {
        val values = shape.adjustData

        val len = min(rect.width(), rect.height()).toFloat()
        val width = len
        val height = len
        var a = 0f
        var b = 0f
        if (values != null && values.size == 1) {
            if (values[0]!! > 0.5f) {
                values[0] = 0.5f
            }
            a = len * values[0]!!
            b = len * values[0]!!
        } else {
            a = len * 0.125f
            b = len * 0.125f
        }

        val outA = width / 2
        val outB = height / 2

        val path = StarPathBuilder.getStarPath(outA.toInt(), outB.toInt(), a.toInt(), b.toInt(), 4)

        sm.reset()
        sm.postScale(rect.width() / len, rect.height() / len)
        path.transform(sm)
        path.offset(rect.centerX().toFloat(), rect.centerY().toFloat())

        return path
    }

    private fun getStar5Path(shape: AutoShape, rect: Rect): Path {
        val values = shape.adjustData

        val len = min(rect.width(), rect.height()).toFloat()
        var width = len
        var height = len
        var a = 0f
        var b = 0f
        if (values != null && values.size == 3) {
            width = width * values[1]!!
            height = height * values[2]!!

            if (values[0]!! > 0.5f) {
                values[0] = 0.5f
            }
            a = width * values[0]!!
            b = height * values[0]!!
        } else {
            width = width * 1.05146f
            height = height * 1.10557f

            a = width * 0.2f
            b = height * 0.2f
        }

        val outA = width / 2
        val outB = height / 2

        val path = StarPathBuilder.getStarPath(outA.toInt(), outB.toInt(), a.toInt(), b.toInt(), 5)

        sm.reset()
        sm.postScale(rect.width() / len, rect.height() / len)
        path.transform(sm)

        height = height * rect.height() / len
        path.offset(rect.centerX().toFloat(), rect.centerY() + (height - rect.height()) / 2)

        return path
    }

    private fun getStar6Path(shape: AutoShape, rect: Rect): Path {
        val values = shape.adjustData

        val len = min(rect.width(), rect.height()).toFloat()
        var width = len
        val height = len
        var a = 0f
        var b = 0f
        if (values != null && values.size == 2) {
            width = width * values[1]!!

            if (values[0]!! > 0.5f) {
                values[0] = 0.5f
            }
            a = width * values[0]!!
            b = height * values[0]!!
        } else {
            width = width * 1.15470f

            a = width * 0.28f
            b = height * 0.28f
        }

        val outA = width / 2
        val outB = height / 2

        val path = StarPathBuilder.getStarPath(outA.toInt(), outB.toInt(), a.toInt(), b.toInt(), 6)

        sm.reset()
        sm.postScale(rect.width() / len, rect.height() / len)
        path.transform(sm)
        path.offset(rect.centerX().toFloat(), rect.centerY().toFloat())

        return path
    }

    private fun getStar7Path(shape: AutoShape, rect: Rect): Path {
        val values = shape.adjustData

        val len = min(rect.width(), rect.height()).toFloat()
        var width = len
        var height = len
        var a = 0f
        var b = 0f
        if (values != null && values.size == 3) {
            width = width * values[1]!!
            height = height * values[2]!!

            if (values[0]!! > 0.5f) {
                values[0] = 0.5f
            }
            a = width * values[0]!!
            b = height * values[0]!!
        } else {
            width = width * 1.02572f
            height = height * 1.05210f

            a = width * 0.32f
            b = height * 0.32f
        }

        val outA = width / 2
        val outB = height / 2

        val path = StarPathBuilder.getStarPath(outA.toInt(), outB.toInt(), a.toInt(), b.toInt(), 7)

        sm.reset()
        sm.postScale(rect.width() / len, rect.height() / len)
        path.transform(sm)
        path.offset(rect.centerX().toFloat(), rect.centerY().toFloat())

        return path
    }

    private fun getStar8Path(shape: AutoShape, rect: Rect): Path {
        val values = shape.adjustData

        val len = min(rect.width(), rect.height()).toFloat()
        val width = len
        val height = len
        var a = 0f
        var b = 0f
        if (values != null && values.size == 1) {
            if (values[0]!! > 0.5f) {
                values[0] = 0.5f
            }
            a = width * values[0]!!
            b = height * values[0]!!
        } else {
            a = width * 0.36f
            b = height * 0.36f
        }

        val outA = width / 2
        val outB = height / 2

        val path = StarPathBuilder.getStarPath(outA.toInt(), outB.toInt(), a.toInt(), b.toInt(), 8)

        sm.reset()
        sm.postScale(rect.width() / len, rect.height() / len)
        path.transform(sm)
        path.offset(rect.centerX().toFloat(), rect.centerY().toFloat())

        return path
    }

    private fun getStar10Path(shape: AutoShape, rect: Rect): Path {
        val values = shape.adjustData

        val len = min(rect.width(), rect.height()).toFloat()
        var width = len
        val height = len
        var a = 0f
        var b = 0f
        if (values != null && values.size == 2) {
            width = width * values[1]!!

            if (values[0]!! > 0.5f) {
                values[0] = 0.5f
            }
            a = width * values[0]!!
            b = height * values[0]!!
        } else {
            width = width * 1.05146f

            a = width * 0.42f
            b = height * 0.42f
        }

        val path = StarPathBuilder.getStarPath(
            width.toInt() / 2,
            height.toInt() / 2,
            a.toInt(),
            b.toInt(),
            10
        )

        sm.reset()
        sm.postScale(rect.width() / len, rect.height() / len)
        path.transform(sm)
        path.offset(rect.centerX().toFloat(), rect.centerY().toFloat())

        return path
    }


    private fun getStar12Path(shape: AutoShape, rect: Rect): Path {
        val values = shape.adjustData

        val len = min(rect.width(), rect.height()).toFloat()
        val width = len
        val height = len
        var a = 0f
        var b = 0f
        if (values != null && values.size == 1) {
            if (values[0]!! > 0.5f) {
                values[0] = 0.5f
            }
            a = width * values[0]!!
            b = height * values[0]!!
        } else {
            a = width * 0.368f
            b = height * 0.368f
        }

        val path = StarPathBuilder.getStarPath(
            width.toInt() / 2,
            height.toInt() / 2,
            a.toInt(),
            b.toInt(),
            12
        )

        sm.reset()
        sm.postScale(rect.width() / len, rect.height() / len)
        path.transform(sm)
        path.offset(rect.centerX().toFloat(), rect.centerY().toFloat())

        return path
    }


    private fun getStar16Path(shape: AutoShape, rect: Rect): Path {
        val values = shape.adjustData

        val len = min(rect.width(), rect.height()).toFloat()
        val width = len
        val height = len
        var a = 0f
        var b = 0f
        if (values != null && values.size == 1) {
            if (values[0]!! > 0.5f) {
                values[0] = 0.5f
            }
            a = width * values[0]!!
            b = height * values[0]!!
        } else {
            a = width * 0.368f
            b = height * 0.368f
        }

        val path = StarPathBuilder.getStarPath(
            width.toInt() / 2,
            height.toInt() / 2,
            a.toInt(),
            b.toInt(),
            16
        )

        sm.reset()
        sm.postScale(rect.width() / len, rect.height() / len)
        path.transform(sm)
        path.offset(rect.centerX().toFloat(), rect.centerY().toFloat())

        return path
    }


    private fun getStar24Path(shape: AutoShape, rect: Rect): Path {
        val values = shape.adjustData

        val len = min(rect.width(), rect.height()).toFloat()
        val width = len
        val height = len
        var a = 0f
        var b = 0f
        if (values != null && values.size == 1) {
            if (values[0]!! > 0.5f) {
                values[0] = 0.5f
            }
            a = width * values[0]!!
            b = height * values[0]!!
        } else {
            a = width * 0.368f
            b = height * 0.368f
        }

        val path = StarPathBuilder.getStarPath(
            width.toInt() / 2,
            height.toInt() / 2,
            a.toInt(),
            b.toInt(),
            24
        )

        sm.reset()
        sm.postScale(rect.width() / len, rect.height() / len)
        path.transform(sm)
        path.offset(rect.centerX().toFloat(), rect.centerY().toFloat())
        return path
    }


    private fun getStar32Path(shape: AutoShape, rect: Rect): Path {
        val values = shape.adjustData

        val len = min(rect.width(), rect.height()).toFloat()
        val width = len
        val height = len
        var a = 0f
        var b = 0f
        if (values != null && values.size == 1) {
            if (values[0]!! > 0.5f) {
                values[0] = 0.5f
            }
            a = width * values[0]!!
            b = height * values[0]!!
        } else {
            a = width * 0.368f
            b = height * 0.368f
        }

        val path = StarPathBuilder.getStarPath(
            width.toInt() / 2,
            height.toInt() / 2,
            a.toInt(),
            b.toInt(),
            32
        )

        sm.reset()
        sm.postScale(rect.width() / len, rect.height() / len)
        path.transform(sm)
        path.offset(rect.centerX().toFloat(), rect.centerY().toFloat())

        return path
    }
}
