package com.reader.pdfviewer.util

import android.content.Context
import java.io.*

object FileUtils {
    @Throws(IOException::class)
    fun fileFromAsset(context: Context, assetName: String): File {
        val outFile = File(context.getCacheDir(), assetName + "-pdfview.pdf")
        if (assetName.contains("/")) {
            outFile.getParentFile().mkdirs()
        }
        copy(context.getAssets().open(assetName), outFile)
        return outFile
    }

    @Throws(IOException::class)
    fun copy(inputStream: InputStream?, output: File?) {
        var outputStream: OutputStream? = null
        try {
            outputStream = FileOutputStream(output)
            var read = 0
            val bytes = ByteArray(1024)
            while ((inputStream!!.read(bytes).also { read = it }) != -1) {
                outputStream.write(bytes, 0, read)
            }
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close()
                }
            } finally {
                if (outputStream != null) {
                    outputStream.close()
                }
            }
        }
    }
}
